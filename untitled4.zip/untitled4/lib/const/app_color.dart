import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class AppColor{
  static const Color white = Colors.white;


}