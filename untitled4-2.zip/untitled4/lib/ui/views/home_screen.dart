import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
            child: Text(
              'Welcome to Home\n Chorui',
          style: TextStyle(fontFamily: 'Autodex', fontSize: 40),
        )),
      ),
    );
  }
}
