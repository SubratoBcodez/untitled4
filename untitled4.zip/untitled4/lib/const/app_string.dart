class AppString{

  static const app_name = "Food Delivary";

}